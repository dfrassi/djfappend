 DROP TABLE  #__djfappend_field;
 DROP TABLE  #__djfappend_field_type;
 DROP TABLE  #__djfappend_field_value;
 
